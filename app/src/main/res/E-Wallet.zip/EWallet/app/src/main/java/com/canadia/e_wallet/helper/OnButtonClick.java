package com.canadia.e_wallet.helper;

public interface OnButtonClick {
    void buttonClick();
}
