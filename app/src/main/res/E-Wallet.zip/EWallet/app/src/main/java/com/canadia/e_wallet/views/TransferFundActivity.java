package com.canadia.e_wallet.views;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.canadia.e_wallet.R;

public class TransferFundActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transfer_fund);
    }
}